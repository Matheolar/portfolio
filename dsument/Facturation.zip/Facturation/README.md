# **Projet Web : Gestion de Facturation & Devis**

Ce projet a été réalisé dans le cadre de la formation **BUT 2 Informatique**, sous la direction de **Monsieur Christophe Louvet**.

L'objectif était de concevoir une application web complète (PHP/MySQL) respectant des contraintes strictes de base de données (Triggers, Vues, Procédures stockées) pour gérer une activité commerciale (Clients, Devis, Factures, Avoirs).

---

### **👥 Membres du groupe**

* **Lariviere Matheo**  
* **Alkhastov Zhabrail**  
* **Belaidi Mastene**  
* **Belmer Alexis**  
* **Susini Charles**

### **🔗 Accès au site**

Pour accéder au site  :

https://safepay.alwaysdata.net/facturation/  
